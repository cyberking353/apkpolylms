/**
 * Al-Hikma Polytechnic LMS - World-Class Application Controller
 * Handles global routing, responsive state, interactive CBT exam engine,
 * Coursera-style video player notebook, financial payment checkout simulator,
 * chart renders, data table pagination & sorting, and real-time chat.
 */

document.addEventListener('alpine:init', () => {
  Alpine.data('lmsApp', () => ({
    // Global Navigation & State
    currentView: 'landing', // landing | login | student | lecturer | hod | registry | bursary | admin | video | cbt | transcript | course-reg | fees | messaging | components
    userRole: 'student', // student | lecturer | hod | registry | bursary | admin
    mobileMenuOpen: false,
    searchModalOpen: false,
    searchQuery: '',
    
    // Notification Toast State
    toast: {
      show: false,
      title: '',
      message: '',
      type: 'blue' // blue | red
    },

    // Login Form State
    loginRole: 'student',
    loginForm: {
      matricNo: '',
      password: '',
      showPassword: false,
      remember: true
    },

    // Public Portal / Department Filter Hierarchy
    deptHierarchy: {
      school: 'School of Technology',
      department: 'Computer Science',
      programme: 'National Diploma (ND)',
      level: 'ND I',
      semester: 'First Semester'
    },

    // Payment Checkout Modal State
    paymentModal: {
      open: false,
      feeType: 'Tuition & Academic Fees',
      amount: '95,000',
      cardNumber: '4532 •••• •••• 8892',
      expiry: '08/28',
      cvv: '•••',
      processing: false,
      success: false
    },
    
    // CBT Exam Simulator Engine
    cbt: {
      timerSeconds: 1800, // 30 mins
      timerInterval: null,
      currentQuestion: 0,
      calculatorOpen: false,
      calcDisplay: '0',
      flagged: {},
      answers: {},
      questions: [
        {
          id: 1,
          code: 'COM 111',
          title: 'Introduction to Computer Programming',
          text: 'Which of the following linear data structures operates strictly on a Last-In, First-Out (LIFO) memory access mechanism?',
          options: ['A) Double-Ended Queue (Deque)', 'B) Call Stack', 'C) Binary Search Tree (BST)', 'D) Circular Linked List'],
          correct: 'B) Call Stack',
          explanation: 'A stack stores elements in LIFO order, where push and pop operations occur exclusively at the top of the stack.'
        },
        {
          id: 2,
          code: 'COM 111',
          title: 'Introduction to Computer Programming',
          text: 'What is the tight worst-case asymptotic time complexity of searching an element in a balanced Binary Search Tree (BST)?',
          options: ['A) O(1)', 'B) O(n)', 'C) O(log n)', 'D) O(n log n)'],
          correct: 'C) O(log n)',
          explanation: 'In a balanced BST of height h = log2(n), each comparison eliminates half the remaining subtrees, yielding O(log n).'
        },
        {
          id: 3,
          code: 'COM 111',
          title: 'Introduction to Computer Programming',
          text: 'In ANSI C programming, which unary operator is evaluated to extract the exact physical memory address of a declared variable?',
          options: ['A) Dereference operator (*)', 'B) Address-of operator (&)', 'C) Bitwise XOR operator (^)', 'D) Modulo operator (%)'],
          correct: 'B) Address-of operator (&)',
          explanation: 'The & operator yields a pointer containing the memory location address of its operand variable.'
        },
        {
          id: 4,
          code: 'COM 111',
          title: 'Introduction to Computer Programming',
          text: 'Which SQL keyword is explicitly specified in a SELECT query to eliminate redundant duplicate rows from the returned result set?',
          options: ['A) UNIQUE', 'B) DISTINCT', 'C) GROUP BY', 'D) HAVING'],
          correct: 'B) DISTINCT',
          explanation: 'SELECT DISTINCT filters out matching duplicate records across selected columns.'
        },
        {
          id: 5,
          code: 'COM 111',
          title: 'Introduction to Computer Programming',
          text: 'Which HTTP network request method is idempotent and defined to replace the targeted resource payload completely?',
          options: ['A) POST', 'B) GET', 'C) PUT', 'D) PATCH'],
          correct: 'C) PUT',
          explanation: 'PUT requests create or overwrite a resource at a specific URI in an idempotent manner.'
        }
      ],
      showSubmitModal: false,
      submitted: false,
      score: 0
    },

    // Course Registration State
    courseReg: {
      search: '',
      levelFilter: 'ND I',
      maxUnits: 24,
      courses: [
        { code: 'COM 111', title: 'Introduction to Computing & Logic', units: 3, category: 'Core', selected: true, status: 'Registered' },
        { code: 'COM 112', title: 'Introduction to Digital Electronics', units: 3, category: 'Core', selected: true, status: 'Registered' },
        { code: 'COM 113', title: 'Data Structures & Algorithms I', units: 4, category: 'Core', selected: true, status: 'Registered' },
        { code: 'GNS 101', title: 'Use of English & Communication I', units: 2, category: 'General', selected: true, status: 'Registered' },
        { code: 'MTH 111', title: 'Logic & Linear Algebra', units: 3, category: 'General', selected: true, status: 'Registered' },
        { code: 'COM 114', title: 'Web Development & Scripting Fundamentals', units: 3, category: 'Elective', selected: false, status: 'Available' },
        { code: 'COM 115', title: 'Computer Hardware System Diagnostics', units: 3, category: 'Elective', selected: false, status: 'Available' }
      ]
    },

    // Coursera-Style Video Player State
    video: {
      playing: false,
      speed: '1.0x',
      captions: true,
      activeTab: 'outline', // outline | notes | resources | discussion
      notes: 'Key Concept: Stacks execute LIFO access order. Push pushes onto top; Pop removes top element.',
      savedNotes: [
        { timestamp: '04:15', text: 'Definition of Stack Pointer (SP) register in CPU architecture.' },
        { timestamp: '11:40', text: 'Call Stack stack frame layout: Return Address, Frame Pointer, Parameters, Local Variables.' }
      ],
      discussionInput: '',
      discussions: [
        { name: 'Dr. A. O. Bello (Course Lecturer)', time: '2 hours ago', text: 'Remember to practice implementing stack push/pop functions using struct pointers before Friday lab.' },
        { name: 'Suleiman Ibrahim (ND I Student)', time: '45 mins ago', text: 'Is stack overflow error caused when SP exceeds allocated array boundaries?' }
      ]
    },

    // Messaging UI State (Slack/Teams style)
    chat: {
      activeChannel: '#cs-dept-hnd1',
      channels: ['#cs-dept-hnd1', '#lms-support-desk', '#nd1-announcements', '#bursary-helpdesk'],
      messageInput: '',
      messages: [
        { sender: 'Dr. K. A. Adeleke (HOD)', time: '10:14 AM', text: 'Good morning class. The official CBT mid-semester examination timetable has been published.' },
        { sender: 'Aisha Bello (Course Rep)', time: '10:20 AM', text: 'Thank you Sir! We have acknowledged the schedule for COM 111 and COM 112.' },
        { sender: 'You (Student)', time: '10:25 AM', text: 'Will the afternoon practical lab session commence at 2:00 PM today?' }
      ]
    },

    // Data Table State & Mock Data (Search, Multi-column Sorting, Pagination, CSV Export)
    studentTable: {
      search: '',
      sortKey: 'name',
      sortAsc: true,
      currentPage: 1,
      pageSize: 5,
      items: [
        { id: 'AH/ND/2024/001', name: 'Ahmad Usman', dept: 'Computer Science', level: 'ND I', cgpa: '3.85', status: 'Active' },
        { id: 'AH/ND/2024/002', name: 'Fatima Z. Abubakar', dept: 'Computer Science', level: 'ND I', cgpa: '3.92', status: 'Active' },
        { id: 'AH/ND/2024/003', name: 'Kabir O. Mohammed', dept: 'Electrical Eng', level: 'ND II', cgpa: '3.40', status: 'Active' },
        { id: 'AH/HND/2024/012', name: 'Blessing A. Johnson', dept: 'Accountancy', level: 'HND I', cgpa: '3.68', status: 'Active' },
        { id: 'AH/HND/2024/015', name: 'Yusuf O. Alabi', dept: 'Mass Communication', level: 'HND II', cgpa: '3.75', status: 'Active' },
        { id: 'AH/ND/2024/020', name: 'Zainab T. Isa', dept: 'Statistics', level: 'ND I', cgpa: '3.50', status: 'Active' },
        { id: 'AH/ND/2024/025', name: 'Mustapha K. Umar', dept: 'Computer Science', level: 'ND II', cgpa: '3.95', status: 'Active' }
      ]
    },

    // App Initialization
    init() {
      this.startCbtTimer();
      
      // Global Keyboard Shortcut: Cmd+K / Ctrl+K search modal listener
      window.addEventListener('keydown', (e) => {
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
          e.preventDefault();
          this.searchModalOpen = !this.searchModalOpen;
        }
      });

      // Initialize Chart.js visuals after DOM render
      this.$nextTick(() => {
        this.renderCharts();
      });
    },

    // Navigation View Switcher
    switchView(viewName, role = null) {
      this.currentView = viewName;
      if (role) {
        this.userRole = role;
      }
      this.mobileMenuOpen = false;
      window.scrollTo({ top: 0, behavior: 'smooth' });
      this.showToast('Navigated View', `Switched view to ${viewName.toUpperCase().replace('-', ' ')}`, 'blue');
      
      // Re-render chart graphs if transitioning to dashboard
      this.$nextTick(() => {
        this.renderCharts();
      });
    },

    // Toast Generator
    showToast(title, message, type = 'blue') {
      this.toast.title = title;
      this.toast.message = message;
      this.toast.type = type;
      this.toast.show = true;
      setTimeout(() => {
        this.toast.show = false;
      }, 3500);
    },

    // CBT Methods
    startCbtTimer() {
      if (this.cbt.timerInterval) clearInterval(this.cbt.timerInterval);
      this.cbt.timerInterval = setInterval(() => {
        if (this.cbt.timerSeconds > 0) {
          this.cbt.timerSeconds--;
        }
      }, 1000);
    },

    formatTime(seconds) {
      const m = Math.floor(seconds / 60);
      const s = seconds % 60;
      return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    },

    toggleFlag(index) {
      this.cbt.flagged[index] = !this.cbt.flagged[index];
    },

    calcInput(val) {
      if (val === 'C') {
        this.cbt.calcDisplay = '0';
      } else if (val === '=') {
        try {
          this.cbt.calcDisplay = eval(this.cbt.calcDisplay.replace('x', '*')).toString();
        } catch (e) {
          this.cbt.calcDisplay = 'Error';
        }
      } else {
        if (this.cbt.calcDisplay === '0' || this.cbt.calcDisplay === 'Error') {
          this.cbt.calcDisplay = val;
        } else {
          this.cbt.calcDisplay += val;
        }
      }
    },

    submitCbtExam() {
      let correctCount = 0;
      this.cbt.questions.forEach((q, idx) => {
        if (this.cbt.answers[idx] === q.correct) {
          correctCount++;
        }
      });
      this.cbt.score = Math.round((correctCount / this.cbt.questions.length) * 100);
      this.cbt.submitted = true;
      this.cbt.showSubmitModal = false;
      this.showToast('CBT Exam Submitted', `Your score: ${this.cbt.score}% — Grade computed.`, 'blue');
    },

    // Financial Payment Checkout Logic
    processPayment() {
      this.paymentModal.processing = true;
      setTimeout(() => {
        this.paymentModal.processing = false;
        this.paymentModal.success = true;
        this.showToast('Payment Successful', 'Receipt #AH-PAY-88912 generated.', 'blue');
        setTimeout(() => {
          this.paymentModal.open = false;
          this.paymentModal.success = false;
        }, 2000);
      }, 1500);
    },

    // Course Registration Credit Unit Calculator
    get totalRegisteredUnits() {
      return this.courseReg.courses
        .filter(c => c.selected)
        .reduce((sum, c) => sum + c.units, 0);
    },

    toggleCourseSelection(index) {
      const course = this.courseReg.courses[index];
      if (!course.selected && (this.totalRegisteredUnits + course.units) > this.courseReg.maxUnits) {
        this.showToast('Credit Limit Exceeded', `Cannot exceed maximum ${this.courseReg.maxUnits} credit units per semester!`, 'red');
        return;
      }
      course.selected = !course.selected;
      course.status = course.selected ? 'Registered' : 'Available';
    },

    // Video Learning Discussions & Notes
    addDiscussion() {
      if (!this.video.discussionInput.trim()) return;
      this.video.discussions.unshift({
        name: 'You (Student)',
        time: 'Just now',
        text: this.video.discussionInput
      });
      this.video.discussionInput = '';
      this.showToast('Question Posted', 'Question submitted to course discussion board.', 'blue');
    },

    saveNote() {
      if (!this.video.notes.trim()) return;
      this.video.savedNotes.unshift({
        timestamp: '14:20',
        text: this.video.notes
      });
      this.showToast('Note Saved', 'Saved to your personal lecture notebook.', 'blue');
    },

    // Messaging UI Sender
    sendMessage() {
      if (!this.chat.messageInput.trim()) return;
      this.chat.messages.push({
        sender: 'You (Student)',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        text: this.chat.messageInput
      });
      this.chat.messageInput = '';
    },

    // Data Table Filtering & Sorting
    get filteredStudents() {
      let result = this.studentTable.items.filter(s => {
        const query = this.studentTable.search.toLowerCase();
        return s.name.toLowerCase().includes(query) ||
               s.id.toLowerCase().includes(query) ||
               s.dept.toLowerCase().includes(query);
      });

      result.sort((a, b) => {
        let valA = a[this.studentTable.sortKey];
        let valB = b[this.studentTable.sortKey];
        if (valA < valB) return this.studentTable.sortAsc ? -1 : 1;
        if (valA > valB) return this.studentTable.sortAsc ? 1 : -1;
        return 0;
      });

      return result;
    },

    sortStudents(key) {
      if (this.studentTable.sortKey === key) {
        this.studentTable.sortAsc = !this.studentTable.sortAsc;
      } else {
        this.studentTable.sortKey = key;
        this.studentTable.sortAsc = true;
      }
    },

    exportCSV() {
      let csvContent = "data:text/csv;charset=utf-8,Matric ID,Student Name,Department,Level,CGPA,Status\n";
      this.filteredStudents.forEach(s => {
        csvContent += `"${s.id}","${s.name}","${s.dept}","${s.level}","${s.cgpa}","${s.status}"\n`;
      });
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", "Al-Hikma_Student_Academic_Records.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      this.showToast('Data Exported', 'Downloaded student record dataset as CSV.', 'blue');
    },

    triggerPrint() {
      window.print();
    },

    // Render Canvas Analytics Charts using Chart.js
    renderCharts() {
      // 1. Student Progress Canvas Chart
      const studentCtx = document.getElementById('studentProgressChart');
      if (studentCtx && typeof Chart !== 'undefined') {
        new Chart(studentCtx, {
          type: 'line',
          data: {
            labels: ['ND I (Sem 1)', 'ND I (Sem 2)', 'ND II (Sem 1)', 'ND II (Sem 2)'],
            datasets: [{
              label: 'Semester GPA Trajectory',
              data: [3.70, 3.82, 3.85, 3.92],
              borderColor: '#0057B8',
              backgroundColor: 'rgba(0, 87, 184, 0.1)',
              borderWidth: 3,
              fill: true,
              tension: 0.4
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
              y: { min: 2.0, max: 4.0 }
            }
          }
        });
      }

      // 2. Bursary Financial Revenue Chart
      const bursaryCtx = document.getElementById('bursaryRevenueChart');
      if (bursaryCtx && typeof Chart !== 'undefined') {
        new Chart(bursaryCtx, {
          type: 'bar',
          data: {
            labels: ['Tuition Fees', 'LMS Licensing', 'CBT Exam Fees', 'Library Fees'],
            datasets: [{
              label: 'Revenue (Millions NGN)',
              data: [95.5, 22.8, 15.2, 11.7],
              backgroundColor: ['#0057B8', '#003D82', '#D62828', '#A31C1C'],
              borderRadius: 8
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } }
          }
        });
      }
    }
  }));
});
